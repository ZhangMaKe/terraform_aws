def handler():
    print('lambda function called')